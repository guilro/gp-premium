})(jQuery, Generate_Sections);
