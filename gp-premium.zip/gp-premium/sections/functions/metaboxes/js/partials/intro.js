/*-----------------------------------------------------------------------------------*/
/* Generate Sections Metabox
/*
/* © Kathy Darling http://www.kathyisawesome.com
/* 2016-07-19. */
/*-----------------------------------------------------------------------------------*/

/**
 * @type {Object} JavaScript namespace for our application.
 */
var Generate_Sections = {
    backbone_modal: {
        __instance: undefined
    }
};

(function($, Generate_Sections) {
