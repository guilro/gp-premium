<?php
// No direct access, please
if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! function_exists( 'generate_ie_init' ) ) :
add_action('init', 'generate_ie_init');
function generate_ie_init() {
	load_plugin_textdomain( 'generate-ie', false, 'gp-premium/import-export/languages' );
}
endif;